﻿using System.Windows;

namespace ConwayGameOfLife_student
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
